const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process'); //polecenia systemowe
const path = require('path');
const app = express();

const DB = new sqlite3.Database('resources/railway.db', (err) => {
    if(err){
        console.err('Błąd połączenia z bazą danych:', err);
    } else {
        console.log('Połączono z bazą daych');
    }
});

module.exports = function testselect(event) {
    
};
