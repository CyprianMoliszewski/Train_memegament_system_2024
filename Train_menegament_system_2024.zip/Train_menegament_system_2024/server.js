const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process'); //polecenia systemowe
const path = require('path');

const app = express();
const port = 8787;

app.use(cors());
app.use(express.static(path.join(__dirname, 'webside/sides')));
app.use(express.static(path.join(__dirname, 'webside')));
app.use(bodyParser.json()); //obsługa json
app.use(bodyParser.urlencoded({ extended: true }));

const DB = new sqlite3.Database('resources/railway.db', (err) => {
    if(err){
        console.err('Błąd połączenia z bazą danych:', err);
    } else {
        console.log('Połączono z bazą daych');
    }
});
app.post('/search', (req, res) => {
    const { from_station, to_station, date } = req.body;
    console.log("Dane są gitara",req.body);
    const query = `
    SELECT Stations.station_name, Stops.stop_number, Schedule_1.arrival_time, Stations_1.station_name, Stops_1.stop_number, Schedule.arrival_time, Routes.route_name
FROM Stations AS Stations_1 INNER JOIN (Routes INNER JOIN (Stops AS Stops_1 INNER JOIN (((Stations INNER JOIN Stops ON Stations.id_station = Stops.id_station) INNER JOIN Schedule AS Schedule_1 ON (Stops.id_route = Schedule_1.id_route) AND (Stops.stop_number = Schedule_1.stop_number)) INNER JOIN Schedule ON Schedule_1.course_number = Schedule.course_number) ON (Stops_1.id_route = Schedule.id_route) AND (Stops_1.stop_number = Schedule.stop_number)) ON Routes.id_route = Stops_1.id_route) ON Stations_1.id_station = Stops_1.id_station
WHERE (((Stations.station_name)= from_station = ? ) And ((Stops.stop_number)<Stops_1.stop_number) And ((Schedule_1.arrival_time)> to_station = ? ) And ((Stations_1.station_name)= date = ? ) And ((Stops.id_route)=Stops_1.id_route))
ORDER BY 3, 6;`;
DB.all(query, [from_station, to_station, date], (err, rows) => {
    if (err) {
        console.error('Błąd zapytania:', err);
        res.status(500).send('Błąd zapytania');
        return;
    }        // Jeśli zapytanie zakończy się powodzeniem, zwróć dane w formacie JSON
    res.json(rows); // Wyślij dane z bazy danych do klienta
    });
});



app.listen(port, () => {
    console.log('Serwer działa na porcie', port);
});


